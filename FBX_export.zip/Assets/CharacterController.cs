﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterController : MonoBehaviour
{

    [SerializeField]
    Animator animController;
	
	// Update is called once per frame
	void Update ()
    {
		if(Input.GetKey(KeyCode.Space))
        {
            animController.SetBool("jump", true);
            animController.SetBool("walk", false);
        }

        if(Input.GetKey(KeyCode.Z))
        {
            animController.SetBool("walk", true);
            animController.SetBool("jump", false);
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            animController.SetBool("walk", false);
            animController.SetBool("jump", false);
        }
    }
}
